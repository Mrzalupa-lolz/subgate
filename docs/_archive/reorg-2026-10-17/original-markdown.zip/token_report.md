# Codex Token Usage Analysis

Generated: 2026-10-14 16:46:19 | Range: All time

## Grand Totals

- **Projects**: 1
- **Sessions**: 2
- **Total tokens**: 96,369,294
  - Input: 95,968,187
  - Cached input: 71,514,347
  - Output: 401,107
  - Reasoning output: 88,986
- **Subagent sessions**: 1 (25,009,344 tokens)
- **Subagents with missing parent in range**: 0

## By Project

| Project | Sessions | Total | Input | Cached Input | Output | Reasoning | Subagents |
|---------|----------|-------|-------|--------------|--------|-----------|-----------|
| SubGate | 2 | 96,369,294 | 95,968,187 | 71,514,347 | 401,107 | 88,986 | 1 (25,009,344) |

## Most Costly Sessions

### 1. SubGate - 71,359,950 tokens
- **Session**: `01a138eb-f78e-7b31-8fb8-c9861b2feaf5`
- **Started**: 2026-10-14 05:39:10
- **CWD**: `/home/subgate/work/SubGate`
- **Direct subagents**: 1
- **Tokens**: input=71,012,249, cached_input=54,924,757, output=347,701, reasoning=72,388

## Highest Input/Output Ratios

| # | Project | Session | Input/Output | Cached/Output | Total Tokens | First Prompt |
|---|---------|---------|--------------|---------------|--------------|--------------|
| 1 | SubGate | `01a138eb...` | 204.2x | 158.0x | 71,359,950 |  |

## Subagent Overhead Hotspots

| # | Project | Parent Session | Descendant Subagents | Descendant Tokens | Overhead vs Parent | Parent Tokens | First Prompt |
|---|---------|----------------|---------------------|-------------------|------------------|---------------|--------------|
| 1 | SubGate | `01a138eb...` | 1 | 25,009,344 | 35.0% | 71,359,950 |  |

## Most Costly Subagents

| # | Project | Parent Session | Subagent | Role | Total Tokens | Input | Cached Input | Output |
|---|---------|----------------|----------|------|--------------|-------|--------------|--------|
| 1 | SubGate | `01a138eb...` | /root/security_reviewer | ? | 25,009,344 | 24,955,938 | 16,589,590 | 53,406 |

## Subagent Usage By Project

| Project | Subagent Sessions | Subagent Tokens |
|---------|-------------------|-----------------|
| SubGate | 1 | 25,009,344 |

## Usage By Originator

| Originator | Sessions | Total Tokens | Subagent Sessions |
|------------|----------|--------------|-------------------|
| codex-tui | 2 | 96,369,294 | 1 |

## Usage By Agent Role

| Agent Role | Sessions | Total Tokens | Subagent Sessions |
|------------|----------|--------------|-------------------|
| unknown | 2 | 96,369,294 | 1 |

## Usage By Workspace Kind

| Workspace Kind | Sessions | Total Tokens | Subagent Sessions |
|----------------|----------|--------------|-------------------|
| repo root/other | 2 | 96,369,294 | 1 |

## Most Instruction-Heavy Sessions

| # | Project | Session | Base Instr Chars | Max Turn Instr Chars | Combined Chars | Est. Tokens | First Prompt |
|---|---------|---------|------------------|----------------------|----------------|-------------|--------------|
| 1 | SubGate | `01a138eb...` | 21,769 | 0 | 21,769 | ~5,442 |  |

## Likely Savings Opportunities

- Subagent usage is a major cost center: 25,009,344 of 96,369,294 total tokens (26.0%) are in subagent sessions.
- Context replay dominates output: input/output is 239.3x and cached-input/output is 178.3x across the whole report window.
- A small number of sessions dominate spend: the top 5 non-subagent sessions account for 71,359,950 tokens (74.0% of total usage).
- The largest subagent hotspot is `01a138eb-f78e-7b31-8fb8-c9861b2feaf5` in SubGate: 1 descendant subagents consumed 25,009,344 tokens, equal to 35.0% of the parent session's own token count.
- The heaviest static instruction payload observed was in `01a138eb-f78e-7b31-8fb8-c9861b2feaf5` (SubGate) at 21,769 characters, or about ~5,442 tokens before any repo/file context was added.
